#!/bin/bash
cd ..
tar zcvf init_99bill.tgz init_99bill
