#!/bin/sh

###################################################
# Copyright 2015 VMware, Inc.  All rights reserved.
###################################################

#
# Disable the "switch user" button in the screen lock UI for Neokylin.
# As the command is per user, we need to run it when the user log in instead of installer.
#

. "`dirname $0`/commonlib.sh"

if [ "$(identify_distribution -i)" = " NeoKylin Linux Desktop" ]; then
   dconf write /org/mate/screensaver/user-switch-enabled false
fi

tmpPath="/var/vmware/view.$(whoami)"
if [ -d "$tmpPath" ]; then
   rm -rf "$tmpPath"
fi
mkdir -m 700 "$tmpPath"
if [ "$?" != "0" ]; then
   echo "failed to create $tmpPath"
   exit 18
fi

# Collect the environment variables, will be consumed by the logoff.
touch "$tmpPath/envInfo"
chmod 600 "$tmpPath/envInfo"
env >> "$tmpPath/envInfo"

# Here we need to trim the sid.
sid=$(ps -p $$ -o sid --no-headers | grep -o "[^ ]\+\( \+[^ ]\+\)*")
# Collect the current gnome-session/mate-session process sid, will be consumed by the logoff.
echo "VMW_SESSION_ID=$sid" >> "$tmpPath/envInfo"

# Here we need to save current script PID
# It will be consumed by MonitorLoginUser.sh
echo "VMW_MONITOR_ID=$$" >> "$tmpPath/envInfo"

touch "$tmpPath/screenLockEvent"
chmod 600 "$tmpPath/screenLockEvent"

keyboard=`cat /var/log/vmware/keyboardLayout | awk -F ' ' '{print $2}'`
setxkbmap $keyboard

#Start python to monitor logout and screen lock
/usr/lib/vmware/viewagent/SessionManager.py &

