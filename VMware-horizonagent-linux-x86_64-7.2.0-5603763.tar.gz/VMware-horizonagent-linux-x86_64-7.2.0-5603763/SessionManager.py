#!/usr/bin/python
#encoding=utf-8


###################################################
# Copyright 2015 VMware, Inc.  All rights reserved.
###################################################

import gobject
import dbus
import commands,threading
import time,os
import platform
from dbus.mainloop.glib import DBusGMainLoop

#
#write content to file
#
def writeContentToFile(fileName, content):
    file = open(fileName,'w')
    file.write(content)
    file.close()

class DBusMsgManager:
    #
    #Initialization
    #
    def __init__(self):
        self.CanLogout = False
        self.ScreenLocked = False
        self.ScreenSaverActive = False
        self.IsNeokylin = False
        self.IsRedhat71 = False
        self.IsRedhat72 = False
        self.IsRedhat73 = False
        self.IsUbuntu1204 = False
        self.IsUbuntu1404 = False
        self.IsUbuntu1604 = False
        self.IsSLES12 = False
        self.getDesktopType()
        if self.getVMwareBlastServerRunningStatus() == True:
            self.login = "Client"
        else:
            self.login = "VSphere"

    #
    #Determine desktop type from /var/vmware/view.$USER/desktopType
    #
    def getDesktopType(self):
        self.IsNeokylin = False
        self.IsRedhat71 = False
        self.IsRedhat72 = False
        self.IsRedhat73 = False
        self.IsUbuntu1204 = False
        self.IsUbuntu1404 = False
        self.IsUbuntu1604 = False
        self.IsSLES12 = False
        distro_id = platform.dist()[0]

        (status,user) = commands.getstatusoutput('whoami')
        tmpPath = "/var/vmware/view." + user + "/desktopType"

        while ((os.path.isfile(tmpPath) == False) or (os.stat(tmpPath).st_size == 0)):
            os.system("echo Desktoptype file non-exist or currently empty, continue wait...")
            time.sleep(1)

        file = open(tmpPath, "r")
        self.DesktopType = file.readline().strip('\n')
        file.close()

        if distro_id.strip() == "NeoKylin Linux Desktop":
            self.IsNeokylin = True
        else:
            osInfo = platform.platform().lower()
            if (osInfo.find("redhat") != -1):
                if (osInfo.find("7.1") != -1):
                    self.IsRedhat71 = True
                elif (osInfo.find("7.2") != -1):
                    self.IsRedhat72 = True
                elif (osInfo.find("7.3") != -1):
                    self.IsRedhat73 = True
            elif (osInfo.find("ubuntu") != -1):
                if (osInfo.find("12.04") != -1):
                    self.IsUbuntu1204 = True
                elif (osInfo.find("14.04") != -1):
                    self.IsUbuntu1404 = True
                elif (osInfo.find("16.04") != -1):
                    self.IsUbuntu1604 = True
            elif (distro_id.strip() == "SuSE") and (platform.dist()[1] == "12"):
                self.IsSLES12 = True

    #
    #Create a client to block the logout for some cleanup work
    #
    def create_client(self):
        if self.DesktopType == "gnome":
            self.session_manager = self.session.get_object("org.gnome.SessionManager","/org/gnome/SessionManager")
        else:
            self.session_manager = self.session.get_object("org.mate.SessionManager","/org/mate/SessionManager")
        self.client_id = self.session_manager.RegisterClient("VMwareApp","VMwareAppId")

    #
    #To remove client
    #
    def remove_client(self):
        self.session_manager.UnregisterClient(self.client_id)

    #
    #callback function to process DBus messages
    #
    def message_callback(self,bus,message):
        msg_member = message.get_member()
        if msg_member == "EndSession":
            self.writeLogoutSignalToFile()
            self.Running = False
            self.CanLogout = True
        elif msg_member == "EndSessionResponse":
            self.CanLogout = True
        elif msg_member == "QueryEndSession":
            self.CanLogout = True
        elif msg_member == "CancelEndSession":
            self.CanLogout = False
        elif msg_member == "Stop":
            pass
        elif msg_member == "InhibitorAdded":
            if self.CanLogout == True:
                if self.getCountOfInhibitors() == 1 and self.getCountOfClients() == 1:
                    self.Running = False
                    self.writeLogoutSignalToFile()
        elif msg_member == "InhibitorRemoved":
            if self.CanLogout == True:
                if self.getCountOfInhibitors() == 1:
                    self.Running = False
                    self.writeLogoutSignalToFile()
        elif msg_member == "Lock":
            interface = message.get_interface()
            if (interface == "org.gnome.ScreenSaver") or (interface == "org.mate.ScreenSaver") or (interface == "org.freedesktop.ScreenSaver"):
                self.ScreenLocked = True
                if self.ScreenSaverActive:
                    self.writeScreenStatusToFile(True)
        elif msg_member == "ActiveChanged":
            interface = message.get_interface()
            if (interface == "org.gnome.ScreenSaver") or (interface == "org.mate.ScreenSaver") or (interface == "org.freedesktop.ScreenSaver"):
                args = message.get_args_list()
                self.ScreenSaverActive = args[0]
                if self.ScreenSaverActive:
                    # Test on Redhat 7.1, the ScreenSaver will not call the method 'Lock'.
                    # ActiveChanged with true means screen locked.
                    # Test on Ubuntu 1404, if logged in with Metacity/Compiz mode.
                    # ActiveChanged with true means screen locked.
                    if (self.ScreenLocked) or (self.IsRedhat71) or (self.IsRedhat72) or (self.IsRedhat73) or (self.IsUbuntu1404) or (self.IsUbuntu1604) or (self.IsGnomeFlashBackMode()) or (self.getLockEnabledWhenScreensaverActive()):
                        self.writeScreenStatusToFile(True)
                else:
                    if (self.ScreenLocked) or (self.IsRedhat71) or (self.IsRedhat72) or (self.IsRedhat73) or (self.IsUbuntu1404) or (self.IsUbuntu1604) or (self.IsGnomeFlashBackMode()) or (self.getLockEnabledWhenScreensaverActive()):
                        self.ScreenLocked = False
                        self.writeScreenStatusToFile(False)
        elif msg_member == "EventEmitted":
            args = message.get_args_list()
            if args[0] == "desktop-lock":
                self.writeScreenStatusToFile(True)
            elif args[0] == "desktop-unlock":
                self.writeScreenStatusToFile(False)

    #
    #To start capture DBus messages
    #
    def start(self):
        self.dbus_loop = DBusGMainLoop(set_as_default=True)
        self.session = dbus.SessionBus(mainloop=self.dbus_loop)
        if self.DesktopType == "gnome":
            #self.session.add_match_string_non_blocking("interface='org.gnome.SessionManager'")
            if (self.IsUbuntu1404) or (self.IsUbuntu1604):
                self.session.add_match_string_non_blocking("interface='com.ubuntu.Upstart0_6'")
                self.session.add_match_string_non_blocking("interface='org.gnome.ScreenSaver'")
            else:
                self.session.add_match_string_non_blocking("interface='org.gnome.ScreenSaver'")
            #self.session.add_match_string_non_blocking("interface='org.gnome.SessionManager.ClientPrivate'")
        elif self.DesktopType == "kde":
            self.session.add_match_string_non_blocking("interface='org.freedesktop.ScreenSaver'")
        else:
            #self.session.add_match_string_non_blocking("interface='org.mate.SessionManager'")
            self.session.add_match_string_non_blocking("interface='org.mate.ScreenSaver'")
            #self.session.add_match_string_non_blocking("interface='org.mate.SessionManager.ClientPrivate'")
        self.session.add_message_filter(self.message_callback)
        self.Running = True

    #
    #To stop capture DBus messages
    #
    def stop(self):
        if self.Running == True:
            self.Running = False

    #
    #To get the DBus Message Manager status
    #
    def IsRunning(self):
        return self.Running

    #
    #To check if VMwareBlastServer is running
    #
    def getVMwareBlastServerRunningStatus(self):
        (status,output) = commands.getstatusoutput('pidof VMwareBlastServer')
        if status == 0:
            return True
        else:
            return False

    #
    #Write Logout signal to file
    #
    def writeLogoutSignalToFile(self):
        tmpFile="/var/vmware/viewagent/logEvent"
        (status,user) = commands.getstatusoutput('whoami')
        writeContentToFile(tmpFile, "logout: " + user);

    #
    #Write screen status to file
    #
    def writeScreenStatusToFile(self,lock):
        tmpPath="/var/vmware/view."
        (status,user) = commands.getstatusoutput('whoami')
        if lock == True:
            writeContentToFile(tmpPath + user + \
                     "/screenLockEvent", "screen locked")
        else:
            writeContentToFile(tmpPath + user + \
                     "/screenLockEvent", "screen unlocked")

    #
    # On Redhat 6.6, CentOS 6.6 and Neokylin, there is an option "Lock screen when screen saver is active"
    # If the option is checked, the screen will be locked when the ScreenSaver active.
    # For the above scenario, the dbus monitor will not detect the "Lock" method call.
    # To handle the above, we need to detect the above option checked or not when receive the signal "ActiveChange".
    #
    def getLockEnabledWhenScreensaverActive(self):
        confCmd = "gconftool-2 --get /apps/gnome-screensaver/lock_enabled"
        if (self.IsNeokylin):
            confCmd = "dconf read /org/mate/screensaver/lock-enabled"
        elif (self.IsUbuntu1204) or (self.IsGnomeFlashBackMode() or (self.IsSLES12)):
            confCmd = "gsettings get org.gnome.desktop.screensaver lock-enabled"
        (status, lockEnabled) = commands.getstatusoutput(confCmd)
        return (lockEnabled.lower() == "true")

    #
    #On Ubuntu14.04 installed gnome-session-fallback package, check if user login with Metacity/Compiz mode.
    #
    def IsGnomeFlashBackMode(self):
        if (self.IsUbuntu1404):
            (status, mode) = commands.getstatusoutput("echo $GDMSESSION")
            return (mode == "gnome-fallback" or mode == "gnome-fallback-compiz")
        elif (self.IsUbuntu1604):
            (status, mode) = commands.getstatusoutput("echo $GDMSESSION")
            return (mode == "gnome-flashback-compiz" or mode == "gnome-flashback-metacity")
        else:
            return False

    #
    #To get the number of inhibitors
    #
    def getCountOfInhibitors(self):
        return self.session_manager.GetInhibitors().__len__()

    #
    #To get the number of clients
    #
    def getCountOfClients(self):
        return self.session_manager.GetClients().__len__()

    #
    #Get login type (VSphere or Client)
    #
    def getLoginType(self):
        return self.login

#
#Main starts here
#
if __name__ == "__main__":
    #get pid of current process
    currentPID = os.getpid()

    DBusMsgMgr = DBusMsgManager()
    DBusMsgMgr.start()

    #Create client if needed
    #if DBusMsgMgr.getLoginType() == "Client":
    #    DBusMsgMgr.create_client()

    #Create Main Loop for DBus message processing
    loop = gobject.MainLoop()
    gobject.threads_init()
    context = loop.get_context()

    #The main loop
    while DBusMsgMgr.IsRunning():
        context.iteration(True)

    #Wait until VMwareBlastServer is quit
    if DBusMsgMgr.getLoginType() == "Client":
        while DBusMsgMgr.getVMwareBlastServerRunningStatus():
            time.sleep(1)

    #Remove client
    #if DBusMsgMgr.getLoginType == "Client":
    #    DBusMsgMgr.remove_client()

