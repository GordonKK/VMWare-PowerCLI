const Gio = imports.gi.Gio;
const Lang = imports.lang;
const Signals = imports.signals;

const VmwareCredentialsIface = '<node> \
<interface name="org.vmware.viewagent.Credentials"> \
<signal name="UserAuthenticated"> \
    <arg type="s" name="token"/> \
</signal> \
</interface> \
</node>';

const VmwareCredentialsInfo = Gio.DBusInterfaceInfo.new_for_xml(VmwareCredentialsIface);
const GreeterStatusFile = "/var/vmware/greeter/greeter_status";

let _vmwareCredentialsManager = null;

function VmwareCredentials() {
    var self = new Gio.DBusProxy({ g_connection: Gio.DBus.system,
                                   g_interface_name: VmwareCredentialsInfo.name,
                                   g_interface_info: VmwareCredentialsInfo,
                                   g_name: 'org.vmware.viewagent.Credentials',
                                   g_object_path: '/org/vmware/viewagent/Credentials',
                                   g_flags: (Gio.DBusProxyFlags.DO_NOT_LOAD_PROPERTIES) });
    self.init(null);
    return self;
}

const VmwareCredentialsManager = new Lang.Class({
    Name: 'VmwareCredentialsManager',
    _init: function() {
        this._token = null;

        this._credentials = new VmwareCredentials();
        this._credentials.connectSignal('UserAuthenticated',
                                        Lang.bind(this, this._onUserAuthenticated));


        try {
            log("VMwareSSO : Storing greeter status");
            let file = Gio.file_new_for_path(GreeterStatusFile);
            let fileIoStream = file.open_readwrite(null);
            let outputStream = fileIoStream.get_output_stream();
            outputStream.write("start", null);
            outputStream.close(null);

        } catch (e) {
            log("VMwareSSO Error: " + e.message);
        }
    },

    _onUserAuthenticated: function(proxy, sender, [token]) {
        log("VMwareSSO: get token: " + token);
        this._token = token;
        this.emit('vm-authenticated', token);
    },

    hasToken: function() {
        return this._token != null;
    },

    getToken: function() {
        return this._token;
    },

    resetToken: function() {
        this._token = null;
    }
});
Signals.addSignalMethods(VmwareCredentialsManager.prototype);

function getVmwareCredentialsManager() {
    if (!_vmwareCredentialsManager)
        _vmwareCredentialsManager = new VmwareCredentialsManager();

    return _vmwareCredentialsManager;
}
