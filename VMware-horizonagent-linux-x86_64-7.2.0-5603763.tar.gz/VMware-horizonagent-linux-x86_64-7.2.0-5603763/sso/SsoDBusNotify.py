#!/usr/bin/python
#encoding=utf-8

###################################################
# Copyright 2015 VMware, Inc.  All rights reserved.
###################################################

import dbus
import dbus.service
import gobject
import logging
import os
import time
import getopt
import sys

from dbus.mainloop.glib import DBusGMainLoop
DBusGMainLoop(set_as_default=True)

DBUS_PATH = '/org/vmware/viewagent/Credentials'
DBUS_INTERFACE = 'org.vmware.viewagent.Credentials'
SSO_SOCKET_PATH = '/var/run/vmware/viewagent/sso_socket'

#
# Define the SSO dbus object
#
class SsoDBusObject(dbus.service.Object):

    #
    # Initialization
    #
    def __init__(self):
        bus = dbus.SystemBus()
        dbus.service.Object.__init__(self, bus, DBUS_PATH)
        self._name = dbus.service.BusName(DBUS_INTERFACE, bus)

    #
    # Define the dbus message interface and parameter
    #
    @dbus.service.signal(dbus_interface=DBUS_INTERFACE,
                         signature='s')
    def UserAuthenticated(self, token):
        logging.info("Emitting user authenticated SSO signal.")

    #
    # Send dbus message and exit process
    #
    def sendSsoMessage(self, token):
        self.UserAuthenticated(token)
        exit(0)

#
# Define the Smartcard SSO dbus object
#
class ScSsoDBusObject(dbus.service.Object):

    #
    # Initialization
    #
    def __init__(self):
        bus = dbus.SystemBus()
        dbus.service.Object.__init__(self, bus, DBUS_PATH)
        self._name = dbus.service.BusName(DBUS_INTERFACE, bus)

    #
    # Define the dbus message interface and parameter
    #
    @dbus.service.signal(dbus_interface=DBUS_INTERFACE,
                         signature='s')
    def ScUserAuthenticated(self, token):
        logging.info("Emitting user authenticated SCSSO signal.")

    #
    # Send dbus message and exit process
    #
    def sendSsoMessage(self, token):
        self.ScUserAuthenticated(token)
        exit(0)

if __name__ == "__main__":
    logging.root.level = logging.DEBUG

    try:
        opts, args = getopt.getopt(sys.argv[1:], "t:")
    except getopt.GetoptError:
        exit(1)

    for opt, val in opts:
        if opt == "-t":
           ssotype = val
        else:
           logging.error("Invalid parameter. Usage: SsoDBusNotify.py -t [sso | scsso]")
           exit(1)

    # Get the SSO token from STDIN
    token = raw_input("Please input the token:")

    # Add the access premit of sso socket path in selinux for gdm
    os.system('chcon -R -t xdm_var_run_t ' + SSO_SOCKET_PATH)

    if ssotype == "sso":
        ssoMsg = SsoDBusObject()
    elif ssotype == "scsso":
        ssoMsg = ScSsoDBusObject()
    else:
        logging.error("Invalid SSO type.")
        exit(1)

    # Scheduling the dbus notify event in main loop
    gobject.timeout_add(1000, ssoMsg.sendSsoMessage, token)
    loop = gobject.MainLoop()
    loop.run()
