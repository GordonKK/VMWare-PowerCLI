#!/bin/bash

TMP_PATH="/var/vmware/viewagent"
echo $$ > $TMP_PATH/monitorLogout.pid

. "`dirname $0`/bin/commonlib.sh"

distro_id=$(identify_distribution -i)
if [ "$distro_id" = " NeoKylin Linux Desktop" ]; then
   interface=org.mate.SessionManager
else
   interface=org.gnome.SessionManager
fi
member="Logout"


dbus-monitor --session "interface='$interface',member='$member'" |
while read -r monitorInfo; do
   logoutInfo=$(echo $monitorInfo | grep -i "$member")
   if [ -n "$logoutInfo" ]; then
      echo "logout: "$(whoami) > $TMP_PATH/logEvent
      # Kill the dbus sub process
      pkill -P $$
      # Kill the dbus sub process for the monitor screen lock process
      minitorLockScreenPID=$(cat $TMP_PATH/monitorScreenLock.pid)
      pkill -P $minitorLockScreenPID
   fi
done
