#!/bin/bash

TMP_PATH="/var/vmware/viewagent"
echo $$ > $TMP_PATH/monitorScreenLock.pid

. "`dirname $0`/bin/commonlib.sh"

distro_id=$(identify_distribution -i)
if [ "$distro_id" = " NeoKylin Linux Desktop" ]; then
   interface=org.mate.ScreenSaver
else
   interface=org.gnome.ScreenSaver
fi

dbus-monitor --session "type='signal',interface='$interface'" |
while read -r monitorInfo; do
   if [ -n "$(echo $monitorInfo | grep -i "boolean true")" ]; then
      echo "screen locked" > $TMP_PATH/screenLockEvent
   elif [ -n "$(echo $monitorInfo | grep -i "boolean false")" ]; then
      echo "screen unlocked" > $TMP_PATH/screenLockEvent
   fi
done
