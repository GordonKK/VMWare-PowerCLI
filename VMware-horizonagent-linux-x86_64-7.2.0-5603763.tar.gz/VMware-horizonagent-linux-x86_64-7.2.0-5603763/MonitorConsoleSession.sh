#!/bin/bash

TMP_PATH="/var/vmware"
TMP_ENV_FILE="$TMP_PATH/view.$1/envInfo"
sessionID=$(awk 'BEGIN{FS="="} ($1=="VMW_SESSION_ID") {print $2}' "$TMP_ENV_FILE")

while :
do
   ps -p $sessionID >/dev/null 2>&1
   if [ "$?" = "0" ]; then
      sleep 0.5
   else
      break
   fi
done

envInfo="$TMP_PATH/view.$1/envInfo"
#
# Remove the temporary directory including files inside it
#
if [ -f $envInfo ]; then
   rm -rf "$TMP_PATH/view.$1"
fi

logEventFile="$TMP_PATH/viewagent/logEvent"
echo "logout: "$(cat "$logEventFile") > $logEventFile
